
  # Doctor Appointment Registration Form

  This is a code bundle for Doctor Appointment Registration Form. The original project is available at https://www.figma.com/design/tilbntQuUXWuOOhkwj7lCE/Doctor-Appointment-Registration-Form.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  