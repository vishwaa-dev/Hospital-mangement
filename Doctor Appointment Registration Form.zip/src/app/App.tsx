import { HomePage } from "@/app/components/HomePage";

export default function App() {
  return <HomePage />;
}
