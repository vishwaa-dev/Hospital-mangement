import { Card, CardContent } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import {
  Clock,
  ShieldCheck,
  Award,
  HeartPulse,
  Ambulance,
  Laptop,
  UserCheck,
  Building2,
  Calendar,
} from "lucide-react";

const features = [
  {
    icon: Clock,
    title: "24/7 Emergency Care",
    description: "Round-the-clock emergency services with experienced medical staff",
  },
  {
    icon: ShieldCheck,
    title: "Quality Assurance",
    description: "ISO certified hospital maintaining highest standards of healthcare",
  },
  {
    icon: Award,
    title: "Expert Doctors",
    description: "Highly qualified and experienced medical professionals",
  },
  {
    icon: HeartPulse,
    title: "Advanced Technology",
    description: "State-of-the-art medical equipment and treatment facilities",
  },
  {
    icon: Ambulance,
    title: "Ambulance Service",
    description: "24/7 ambulance service with ICU facilities on wheels",
  },
  {
    icon: Laptop,
    title: "Online Consultations",
    description: "Connect with doctors remotely through telemedicine",
  },
];

const statistics = [
  {
    icon: Building2,
    value: "200+",
    label: "Beds",
    color: "bg-blue-100 text-blue-600",
  },
  {
    icon: UserCheck,
    value: "50+",
    label: "Specialists",
    color: "bg-green-100 text-green-600",
  },
  {
    icon: Award,
    value: "25+",
    label: "Years Experience",
    color: "bg-purple-100 text-purple-600",
  },
  {
    icon: HeartPulse,
    value: "100K+",
    label: "Patients Treated",
    color: "bg-red-100 text-red-600",
  },
];

export function FeaturesSection() {
  return (
    <>
      {/* Why Choose Us Section */}
      <section id="about" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose Kathiravan Hospital?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We combine medical excellence with compassionate care to provide you the best healthcare experience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="border-2 hover:border-blue-200 hover:shadow-lg transition-all">
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Icon className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg text-gray-900 mb-2">
                          {feature.title}
                        </h3>
                        <p className="text-gray-600 text-sm leading-relaxed">
                          {feature.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-20 bg-gradient-to-br from-blue-600 to-indigo-600 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Our Achievements in Numbers
            </h2>
            <p className="text-lg text-blue-100 max-w-2xl mx-auto">
              Building trust through consistent excellence in healthcare delivery
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {statistics.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="flex justify-center mb-4">
                    <div className={`w-16 h-16 ${stat.color} rounded-full flex items-center justify-center`}>
                      <Icon className="w-8 h-8" />
                    </div>
                  </div>
                  <div className="text-4xl md:text-5xl font-bold mb-2">{stat.value}</div>
                  <div className="text-blue-100">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-8 md:p-12 text-white">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-4">
                  Ready to Get Started?
                </h2>
                <p className="text-blue-100 text-lg mb-6">
                  Book your appointment today and experience world-class healthcare. 
                  Our team is ready to serve you 24/7.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Button 
                    size="lg" 
                    className="bg-white text-blue-600 hover:bg-gray-100"
                  >
                    <Calendar className="w-5 h-5 mr-2" />
                    Book Appointment
                  </Button>
                  <Button 
                    size="lg" 
                    variant="outline" 
                    className="border-white text-white hover:bg-white/10"
                  >
                    Contact Us
                  </Button>
                </div>
              </div>
              <div className="hidden md:block">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
                  <h3 className="font-semibold text-xl mb-4">Emergency Contact</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                        <Ambulance className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-sm text-blue-100">24/7 Emergency</div>
                        <div className="font-semibold">+91 123-456-7890</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                        <Calendar className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-sm text-blue-100">Appointments</div>
                        <div className="font-semibold">+91 098-765-4321</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
