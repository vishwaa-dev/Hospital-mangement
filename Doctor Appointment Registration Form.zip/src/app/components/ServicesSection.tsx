import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/app/components/ui/card";
import {
  Heart,
  Brain,
  Bone,
  Baby,
  Eye,
  Activity,
  Pill,
  Scissors,
} from "lucide-react";

const departments = [
  {
    icon: Heart,
    name: "Cardiology",
    description: "Expert heart care with advanced cardiac diagnostics and treatments",
    color: "bg-red-100 text-red-600",
  },
  {
    icon: Brain,
    name: "Neurology",
    description: "Comprehensive neurological care for brain and nervous system disorders",
    color: "bg-purple-100 text-purple-600",
  },
  {
    icon: Bone,
    name: "Orthopedics",
    description: "Specialized bone, joint, and muscle treatment with modern techniques",
    color: "bg-orange-100 text-orange-600",
  },
  {
    icon: Baby,
    name: "Pediatrics",
    description: "Dedicated healthcare for infants, children, and adolescents",
    color: "bg-pink-100 text-pink-600",
  },
  {
    icon: Eye,
    name: "Ophthalmology",
    description: "Advanced eye care and vision correction services",
    color: "bg-cyan-100 text-cyan-600",
  },
  {
    icon: Activity,
    name: "General Medicine",
    description: "Comprehensive primary care for all your health needs",
    color: "bg-green-100 text-green-600",
  },
  {
    icon: Pill,
    name: "Pharmacy",
    description: "24/7 pharmacy with all essential medications and prescriptions",
    color: "bg-blue-100 text-blue-600",
  },
  {
    icon: Scissors,
    name: "Surgery",
    description: "State-of-the-art surgical facilities with experienced surgeons",
    color: "bg-indigo-100 text-indigo-600",
  },
];

const services = [
  {
    title: "Emergency Care",
    description: "24/7 emergency services with rapid response team",
    image: "https://images.unsplash.com/photo-1721114989769-0423619f03d2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMHBhdGllbnQlMjBjYXJlfGVufDF8fHx8MTc2OTU3NzAzOXww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    title: "Advanced Diagnostics",
    description: "Modern imaging and laboratory services for accurate diagnosis",
    image: "https://images.unsplash.com/photo-1762190102324-116a615896da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwZG9jdG9yJTIwdGVhbSUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3Njk1NzcwMzl8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    title: "Inpatient Care",
    description: "Comfortable private and semi-private rooms with modern amenities",
    image: "https://images.unsplash.com/photo-1769147555720-71fc71bfc216?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBob3NwaXRhbCUyMGJ1aWxkaW5nJTIwZXh0ZXJpb3J8ZW58MXx8fHwxNzY5NDg3MjE2fDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
];

export function ServicesSection() {
  return (
    <>
      {/* Departments Section */}
      <section id="departments" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Departments
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Comprehensive healthcare services across multiple specialties with expert medical professionals
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {departments.map((dept, index) => {
              const Icon = dept.icon;
              return (
                <Card
                  key={index}
                  className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-blue-200"
                >
                  <CardHeader>
                    <div className={`w-14 h-14 rounded-full ${dept.color} flex items-center justify-center mb-3`}>
                      <Icon className="w-7 h-7" />
                    </div>
                    <CardTitle className="text-xl">{dept.name}</CardTitle>
                    <CardDescription className="text-sm">
                      {dept.description}
                    </CardDescription>
                  </CardHeader>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Services
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Premium healthcare facilities designed for your comfort and recovery
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-xl transition-shadow">
                <div className="h-48 overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <CardDescription>{service.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
